kubernetes-microservices-project/
│
├── frontend_data_entry/
│   ├── Dockerfile
│   ├── app.py
│   ├── templates/
│   │   └── index.html
│   │
│   └── kubernetes/
│       └── frontend-deployment.yaml
│
├── frontend_data_display/
│   ├── Dockerfile
│   ├── app.py
│   ├── templates/
│   │   └── index.html
│   │
│   └── kubernetes/
│       └── frontend-deployment.yaml
│
├── mongodb/
│   ├── mongo-config.yaml
│   ├── mongo-secret.yaml
│   ├── mongo-deployment.yaml
│
└── README.md

Step 1: Build Docker Images
Create Docker images for both front-end services.

Frontend Data Entry:

cd frontend_data_entry
docker build -t eshaal459/frontend-data-entry .
docker push eshaal459/frontend-data-entry

Frontend Data Display:

cd frontend_data_display
docker build -t eshaal459/frontend-data-display .
docker push eshaal459/frontend-data-display

Step 2: Deploy MongoDB Backend
Apply MongoDB Configuration Files:

kubectl apply -f mongodb/mongo-config.yaml
kubectl apply -f mongodb/mongo-secret.yaml
kubectl apply -f mongodb/mongo-deployment.yaml

Step 3: Deploy Front-End Services

kubectl apply -f kubernetes/frontend-deployment.yaml

Step 4: Verify All Deployments and Services

Check that all pods, services, and deployments are running:

kubectl get deployments
kubectl get pods
kubectl get services

Step 5: To access a service as Internal Service In cluster

minkube service data-entry-service
minikube service data-display-service

Step 6: To access data-display as External Service

kubectl port-forward services/data-display-service 5001:5001