from flask import Flask, render_template
from pymongo import MongoClient
import os

app = Flask(__name__)

# MongoDB connection with authentication using environment variables
mongo_user = os.getenv('MONGO_USER')
mongo_password = os.getenv('MONGO_PASSWORD')

# Ensure the environment variables are set
if not mongo_user or not mongo_password:
    raise ValueError("MongoDB username and password must be set as environment variables.")

# MongoDB connection string with authentication credentials
client = MongoClient(f"mongodb://mongouser:mongopassword@mongo-service:27017/")

db = client["user_data"]  # Database name
collection = db["mydb"]  # Collection name

@app.route("/")
def index():
    # Fetch all records from the collection
    data = list(collection.find())  # Convert cursor to list for easier handling in templates
    
    # Convert _id to string to prevent errors in templates
    for item in data:
        item["_id"] = str(item["_id"])
    
    return render_template("index.html", data=data)  # Use index.html instead of display.html

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)
