from flask import Flask, request, render_template, redirect, url_for
from pymongo import MongoClient
import os

app = Flask(__name__)

# MongoDB connection with authentication using environment variables
mongo_user = os.getenv('MONGO_USER')
mongo_password = os.getenv('MONGO_PASSWORD')

# Connection string with authentication credentials
client = MongoClient(f"mongodb://mongouser:mongopassword@mongo-service:27017/")
db = client["user_data"]  # Database name
collection = db["mydb"]  # Collection name

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        if name and email:
            collection.insert_one({"name": name, "email": email})
            return redirect(url_for("success"))
    return render_template("index.html")

@app.route("/success")
def success():
    return "Data successfully added to MongoDB!"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)